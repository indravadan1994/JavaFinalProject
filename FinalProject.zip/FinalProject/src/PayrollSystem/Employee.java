/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PayrollSystem;

import java.util.ArrayList;

public class Employee implements IPrintable{

//    static void addemployee(FullTime ft1) {
//        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
//    }
//
//    static void addemployee(PartTime pt1) {
//        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
//    }
//    
 private static ArrayList<Employee> employeeList = new ArrayList();
    private int employeeNo;
    private String employeeName;
    private int age;
   
    private double earnings;
    private Vehicle vehicle;
    

    public int getEmployeeNo() {
        return employeeNo;
    }

    public void setEmployeeNo(int employeeNo) {
        this.employeeNo = employeeNo;
    }

    public String getEmployeeName() {
        return employeeName;
    }

    public void setEmployeeName(String employeeName) {
        this.employeeName = employeeName;
    }

    public double getEarnings() {
        return earnings;
    }

    public void setEarnings(double earnings) {
        this.earnings = earnings;
    }

    public Vehicle getVehicle() {
        return vehicle;
    }

    public void setVehicle(Vehicle vehicle) {
        this.vehicle = vehicle;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public static ArrayList<Employee> getEmployeeList() {
        return employeeList;
    }

    public static void setEmployeeList(ArrayList<Employee> employeeList) {
        Employee.employeeList = employeeList;
    }

    public Employee() {
    }

    public Employee(int employeeNo, String employeeName, int age, Vehicle vehicle) {
        this.employeeNo = employeeNo;
        this.employeeName = employeeName;
        this.age = age;
        this.vehicle = vehicle;
    }

    @Override
    public String toString() {

        String str = ("Name : " + this.getEmployeeName());
        return str;

    }

    public static void addEmployee(Employee employee){
        
        employeeList.add(employee);
        
        
        
    }

    public double calcEarnings() {     
     return 1000d;  
    }

    @Override
    public String printMyData() {
        return "Name : " + this.getEmployeeName()+ "\n Age : " + this.getAge();
    }



    


   
}
