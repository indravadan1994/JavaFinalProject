/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PayrollSystem;

import java.util.ArrayList;

/**
 *
 * @author macstudent
 */
public class PayrollSystem {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
     
      MotorCycle m1 = new MotorCycle("Honda","CBR","1997","2012");
      Car c1 = new Car("Mercedes", "Black", "2017", "XLS");
      FullTime ft1 = new FullTime(50000, 20000, 5000, "Indra", 1000, m1);
      Employee.addEmployee(ft1);
      PartTime pt1 = new PartTime(51, 44, 46, "Navjot", 36, m1);
      Employee.addEmployee(pt1);
      
      FixedBasedPartTime fbpt = new FixedBasedPartTime(52, 28, 40, 002, "kirti", 26, c1);
      Employee.addEmployee(fbpt);
      
     Intern int1 = new Intern("Lambton College", 2, "Brinda", 23, c1);
     Employee.addEmployee(int1);
   
     CommissionBasedPartTime cpt1 = new CommissionBasedPartTime(45, 54, 30, 46, "Payal", 84, m1);
      Employee.addEmployee(cpt1);
       
        MotorCycle m2 = new MotorCycle( "TATA", "12Er","1998","Ford");
        
      
        
        Employee employee;
        employee = new Employee(1, "Nirav", 23, m2);
        Employee.addEmployee(employee);
        
        
        

double payroll = 0.0;





      
ArrayList<Employee> employeeList = new ArrayList<>(Employee.getEmployeeList());


for(Employee employeeList1 : employeeList)
{


System.out.println(employeeList1.printMyData());
   
   Vehicle v = new Vehicle();
   v = employeeList1.getVehicle();
   
   if( v == null)
   {
       System.out.println("No Vehicle");
   }
   else
   {
       if( v instanceof Car)
       {
           System.out.println("Has Car");
       }
       else if( v instanceof MotorCycle)
       {
           System.out.println("Has MotorCycle");
       }
       
       System.out.println(v.printMyData());
       
   }
   
   payroll += employeeList1.calcEarnings();
   System.out.println("---------------------------------");
   
}
 
     
 
    System.out.println("Total Payroll: " + payroll);



}
    }
    

