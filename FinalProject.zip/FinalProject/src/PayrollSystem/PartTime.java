/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PayrollSystem;


public class PartTime extends Employee implements IPrintable
{
  
   private int hourlyRate;
    private int numberHoursWorked;

   // PartTime(int i, int i0, String payal, int i1, MotorCycle mc1) {
   //     throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
   // }
    
       public int getHourlyRate()
      {
        return hourlyRate;
    }

    public void setHourlyRate(int hourlyRate) 
    {
        this.hourlyRate = hourlyRate;
    }

    public int getNumberHoursWorked() 
    {
        return numberHoursWorked;
    }

    public void setNumberHoursWorked(int numberHoursWorked) 
    {
        this.numberHoursWorked = numberHoursWorked;
    }

    public PartTime(int hourlyRate, int numberHoursWorked, int employeeNo, String employeeName, int age, Vehicle vehicle) {
        super(employeeNo, employeeName, age, vehicle);
        this.hourlyRate = hourlyRate;
        this.numberHoursWorked = numberHoursWorked;
    }
    
   
   
    
    public PartTime(int hourlyRate, int numberHoursWorked)
    {
        this.hourlyRate = hourlyRate;
        this.numberHoursWorked = numberHoursWorked;
    }

     @Override
    public String toString() {
        return "PartTime{" + "rate=" + hourlyRate + ", noOfHoursWorked=" + numberHoursWorked + '}';
    }

    @Override
    public String printMyData() {
        
        
       return super.printMyData() + "\n - Rate : " + this.getHourlyRate() + "\n - HoursWorked : " + this.getNumberHoursWorked() + " - Salary : " + calcEarnings();
    }
 
  
}
