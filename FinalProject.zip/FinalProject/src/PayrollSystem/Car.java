/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PayrollSystem;

public class Car extends Vehicle implements IPrintable{
    
    private String Brand;
    private String Color;

    public String getBrand() {
        return Brand;
    }

    public void setBrand(String Brand) {
        this.Brand = Brand;
    }

    public String getColor() {
        return Color;
    }

    public void setColor(String Color) {
        this.Color = Color;
    }
    
 
    public Car(String Brand, String Color, String make, String model) {
        super(make, model);
        this.Brand = Brand;
        this.Color = Color;
    }

 
  
      @Override
    public String toString() {
        String str = (" * Brand : " + this.getBrand() + "\n"
                + " * Color : " + this.getColor());
        return super.toString() + str;
    }

    @Override
    public String printMyData() {
         return " Brand :" + this.getBrand() + "\n Model :" + this.getColor();
    }

   
   
}
