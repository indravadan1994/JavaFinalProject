/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PayrollSystem;

public class MotorCycle  extends Vehicle implements IPrintable
{
  
    String mBrand;
    String mModel;

//    MotorCycle(String string, String hondo, String sE4546, String string0, String motorcycle) {
//        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
//    }

    public MotorCycle(String make, String model) {
        super(make, model);
    }

    public String getmBrand() {
        return mBrand;
    }

    public void setmBrand(String mBrand) {
        this.mBrand = mBrand;
    }

    public String getmModel() {
        return mModel;
    }

    public void setmModel(String mModel) {
        this.mModel = mModel;
    }

   
    public MotorCycle(String mBrand, String mModel, String make, String model)
    {
        super(make, model);
        this.mBrand = mBrand;
        this.mModel = mModel;
    }
    
    

    @Override
    public String printMyData() {
        
        return " Make : " + this.getmBrand()+ "\n Model: " + this.getmModel();
    }


  
   
}
