/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PayrollSystem;

public class FullTime extends Employee implements IPrintable
{

   private int Salary;
    private int Bonus;

//    FullTime(int i, int i0, String navjot_Kaur, int i1, Car car1) {
//        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
//    }
    
    
    
       public int getSalary() {
        return Salary;
    }

    public void setSalary(int Salary) {
        this.Salary = Salary;
    }

    public int getBonus() {
        return Bonus;
    }

    public void setBonus(int Bonus) {
        this.Bonus = Bonus;
    }

    public FullTime(int Salary, int Bonus) 
    {
        this.Salary = Salary;
        this.Bonus = Bonus;
    }

    public FullTime(int Salary, int Bonus, int employeeNo, String employeeName, int age, Vehicle vehicle) {
        super(employeeNo, employeeName, age, vehicle);
        this.Salary = Salary;
        this.Bonus = Bonus;
    }


    
    public double calcEarnings()

{
      
       return (double)(this.getSalary() + this.getBonus());
      
    }
    
    

  @Override
    public String printMyData() {
        return super.printMyData() + "\n - salary = " + Salary + ",\n - bonus = " + Bonus + '}';
    }

   
 
}
