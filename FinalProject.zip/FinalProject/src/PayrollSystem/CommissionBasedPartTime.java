/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PayrollSystem;

public class CommissionBasedPartTime extends PartTime {
    private int CommissionAmount;

//    CommissionBasedPartTime(int i, int i0, int i1, String indravadan, int i2, Car car1) {
//        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
//    }

   

  
       public int getCommissionAmount()
    {
        return CommissionAmount;
    }

    public void setCommissionAmount(int CommissionAmount) 
    {
        this.CommissionAmount = CommissionAmount;
    }


    public CommissionBasedPartTime(int CommissionAmount, int hourlyRate, int numberHoursWorked) {
        super(hourlyRate, numberHoursWorked);
        this.CommissionAmount = CommissionAmount;
    }

    public CommissionBasedPartTime(int CommissionAmount, int hourlyRate, int numberHoursWorked, int employeeNo, String employeeName, int age, Vehicle vehicle) {
        super(hourlyRate, numberHoursWorked, employeeNo, employeeName, age, vehicle);
        this.CommissionAmount = CommissionAmount;
    }
    
 
    @Override
    public double calcEarnings() 
    {
        return (double)((this.getNumberHoursWorked() * this.getHourlyRate()) + CommissionAmount);
//To change body of generated methods, choose Tools | Templates.
    }
    
      @Override
    public String toString() {

        String str = ("Employee is Part Time / Commissioned " + "\n"
                + " * Rate : " + getHourlyRate() + "\n"
                + " * Hours Worked : " + getNumberHoursWorked() + "\n"
                + " * Commission : " + getCommissionAmount() + "\n"
                + " * Earnings: " + calcEarnings()
                + "\n");

        return str;

    }
    @Override
    public String printMyData() {
        
        
       return this.toString();
    }
 

 
    
       

   
    
        
        
        
       
    }

   
   
   
   
    
    
  
    

