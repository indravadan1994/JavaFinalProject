/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PayrollSystem;


public class Vehicle implements IPrintable
{

    String Number;
    String model;

    public String getNumber() {
        return Number;
    }

    public void setNumber(String Number) {
        this.Number = Number;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public Vehicle()
    {
        
    }
    public Vehicle(String make, String model) {
        this.Number = make;
        this.model = model;
    }
  
    
//      @Override
//    public String toString() {
//        String str = "Employee has  a: " + this.getModel() + "\n";
//        return str;
//    }

    @Override
    public String printMyData() {
      
     return " Make : " + this.getModel()+ "\n Model: " + this.getNumber();
    }
   

   
}
