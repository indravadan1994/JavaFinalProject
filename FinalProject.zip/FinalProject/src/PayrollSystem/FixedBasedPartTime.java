
package PayrollSystem;

public class FixedBasedPartTime extends PartTime 
{
     private int FixedAmount;

 
     
     public int getFixedAmount() {
        return FixedAmount;
    }

    public void setFixedAmount(int FixedAmount) {
        this.FixedAmount = FixedAmount;
    }

    public FixedBasedPartTime(int FixedAmount, int hourlyRate, int numberHoursWorked) {
        super(hourlyRate, numberHoursWorked);
        this.FixedAmount = FixedAmount;
    }

    public FixedBasedPartTime(int FixedAmount, int hourlyRate, int numberHoursWorked, int employeeNo, String employeeName, int age, Vehicle vehicle) {
        super(hourlyRate, numberHoursWorked, employeeNo, employeeName, age, vehicle);
        this.FixedAmount = FixedAmount;
    }
    
   
  
   

    public double calcEarnings() {
        return (double)((this.getHourlyRate() * this.getNumberHoursWorked()) + FixedAmount); //To change body of generated methods, choose Tools | Templates.
    
    }

     @Override
    public String toString() {

        String str = ("Employee is Part Time / Fixed Amount " + "\n"
                + " * Rate : " + getHourlyRate() + "\n"
                + " * Hours Worked : " + getNumberHoursWorked() + "\n"
                + " * Commission : " + getFixedAmount() + "\n"
                + " * Earnings " + calcEarnings()
                + "\n");

        return str;
    }
     

    
}
